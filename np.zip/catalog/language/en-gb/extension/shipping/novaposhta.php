<?php
// Text
$_['text_title']                  = 'Nova poshta';
$_['text_description_department'] = 'Delivery to the department of Nova poshta';
$_['text_description_doors']      = 'Nova poshta courier shipping to the address';
$_['text_description_poshtomat']  = 'Delivery to the poshtomat of Nova poshta';
$_['text_period']                 = 'Delivery time - ';
$_['text_day_1']                  = 'day';
$_['text_day_2']                  = 'days';
$_['text_day_3']                  = 'days';