<?php
// Text
$_['text_title']                  = 'Новая почта';
$_['text_description_department'] = 'Доставка в отделение Новой почты';
$_['text_description_doors']      = 'Доставка курьером Новой почты на адрес';
$_['text_description_poshtomat']  = 'Доставка в почтомат Новой почты';
$_['text_period']                 = 'Срок доставки - ';
$_['text_day_1']                  = 'день';
$_['text_day_2']                  = 'дня';
$_['text_day_3']                  = 'дней';