<?php
// Text
$_['text_title']                  = 'Нова пошта';
$_['text_description_department'] = 'Доставка у відділення Нової пошти';
$_['text_description_doors']      = 'Доставка кур`єром Нової пошти на адресу';
$_['text_description_poshtomat']  = 'Доставка в поштомат Нової пошти';
$_['text_period']                 = 'Термін доставки - ';
$_['text_day_1']                  = 'день';
$_['text_day_2']                  = 'дні';
$_['text_day_3']                  = 'днів';